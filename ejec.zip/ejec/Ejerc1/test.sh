#!/bin/bash 
in=1
while [ $in -le 20 ];
do
    start=`date +%s`
    ./prog1 < "inputs/input"${in}".txt" > "mo/output"${in}".txt"
    let in=in+1 
    end=`date +%s`
    runtime=$((end-start))
    echo Toma segundos = $runtime
done
in=1
while [ $in -le 20 ];
do
    echo $in
    ./C "outputs/output"${in}".txt" "mo/output"${in}".txt"
    let in=in+1 
done