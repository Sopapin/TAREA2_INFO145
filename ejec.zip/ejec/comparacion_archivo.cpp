#include <iostream> // entrada y salida por consola
#include <fstream>  // entrada y salida por ficheros
#include <string>   // para string
#include <stdlib.h> // para system
#include <stdio.h>  //para remove
#include <iomanip>  // pata setw
using namespace std;

#ifdef linux
#define limpiar system("clear");
#endif

int main(int argc, char *argv[])
{

    string s1;
    string s2;
    s1 = argv[1];
    s2 = argv[2];

    const char *Ruta1 = s1.c_str(); //Las transformo a const char ya que mas a delante
    const char *Ruta2 = s2.c_str(); //las utilizare para abrir ficheros, y si no son const char se queja el compilador
    //basicamente lo que hace s1.c_str() es asignar al puntero Ruta1 la posicion donde empieza el string,

    ifstream File1(Ruta1, ios::in); //Abrimos los dos ficheros en modo de lectura
    ifstream File2(Ruta2, ios::in); //

    //si ambos ficheros se han encontrado y se han abierto correctamente...
    ofstream comparacion("Comparacion.txt", ios::out); //declaramos y abrimos otro fichero en modo de escritura
    bool iguales = true;
    int cont = 0, linea = 0;

    while (!File1.eof() && !File2.eof())
    { // mientras que ninguno de los dos ficheros se haya acabado
        ++linea;
        string a, b;
        getline(File1, a); // metemos en el string a la primera linea del fichero 1
        getline(File2, b); // metemos en el string b la primera linea del fichero 2
        if (a != b)
        { // si son diferentes....
            ++cont;
            comparacion << flush << "Error numero " << cont << " en la linea " << linea << endl
                        << flush;
            iguales = false;
            comparacion << setw(20) << right << s1 << " : " << a << endl;
            comparacion << setw(20) << right << s2 << " : " << b << endl;
        } //Sacamos por pantalla en un formato determinado las diferencias y tambien en un fichero
    }
    if (!File1.eof() && File2.eof())
    { //en el caso de que hayamos llegado al final del primer fichero pero no del segundo...

        comparacion << "El archivo " << Ruta2 << " es mas corto que " << Ruta1 << endl;
    }
    if (!File2.eof() && File1.eof())
    { //... al reves que el anterior
        comparacion << "El archivo " << Ruta1 << " es mas corto que " << Ruta2 << endl;
    }
    comparacion.close(); //cerramos el fichero de salida!! (esto es importante cuando abrimos un fichero mas a delante se ha de cerrar)
    if (iguales)
        cout << "Enhorabuena los dos ficheros son iguales";
    else
        cout << "No";
    remove("Comparacion.txt"); //en el caso de que el usuario no quiera un fichero con las diferencias sacadas por la
                               //consola, pues el que habiamos creado y llenado con todos los datos lo eliminamos
}