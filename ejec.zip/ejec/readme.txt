De la carpeta ejec

make donde estén A1 y A2, # Se tiene que llamar si o si A1 y A2 porque así está el makefile!!

Se van a crear los archivos, prog1 prog2 y C. 

Copiar Prog1 y C a Ejerc1
Copiar Prog2 y C a Ejerc2

Copiar contenido de carpeta Ejerc1 en Tarea2a_INFO145/2A/1 + crear carpeta "mo" + abrir terminar en esta carpeta + ejecutar comando "chmod test.sh"
Copiar contenido de carpeta Ejerc2 en Tarea2a_INFO145/2A/2 + crear carpeta "mo" + abrir terminar en esta carpeta + ejecutar comando "chmod test.sh"

ejecutar "./test.sh" para ejecutar el test, en la carpeta que quieras hacer el test primero 1 o 2 
